export class BillResponseData {     


    /**
     * 결제회원 연동키
     */
    encBill?: String;

    /**
     * 결제회원 키
     */
    billAuthNo?: String;

    /**
     * 카드번호
     */
    cardNo?: String;

    /**
     * 카드사명
     */
    cardName?: String;
}
