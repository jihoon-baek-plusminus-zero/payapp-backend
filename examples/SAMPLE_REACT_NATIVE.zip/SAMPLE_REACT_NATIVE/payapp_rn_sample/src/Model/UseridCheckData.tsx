export class UseridCheckData {
  /**
   * cmd
   * 필수
   */
  cmd?: String;

  /**
   * 판매자 회원 아이디
   * 필수
   */
  userid?: String;

  /**
   * 대리점 또는 리셀러 아이디
   * 필수
   */
  resellerid?: String;
}
