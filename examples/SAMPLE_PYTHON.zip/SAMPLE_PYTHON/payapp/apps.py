from django.apps import AppConfig


class PayappConfig(AppConfig):
    name = 'payapp'
