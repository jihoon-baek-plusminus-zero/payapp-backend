package com.udid.applink.constValue;

/**
 * Create by 김진원
 */
public class PAALConstValue {

    public final static String FALSE_STR = "0";
    public final static String TRUE_STR = "1";
    public final static String PAYAPP_APP_LINK = "https://payapp.kr/sdk-app";

}
