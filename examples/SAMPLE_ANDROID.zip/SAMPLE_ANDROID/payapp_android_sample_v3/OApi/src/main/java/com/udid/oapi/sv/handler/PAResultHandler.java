package com.udid.oapi.sv.handler;

/**
 * Create by 김진원
 */
public interface PAResultHandler<T> {

    void response(T result);

}
